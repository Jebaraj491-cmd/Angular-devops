export interface FoodMenuImage {
  id: number;
  base64Image: string;
  mime: string;
  imageName: string;
  foodMenusId: number;
}
