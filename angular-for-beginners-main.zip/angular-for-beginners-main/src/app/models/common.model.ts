export interface MenuActiveItem {
    id: string;
    isActive: boolean;
}

export interface EventLog {
    color: string;
    message: string;
}