export interface ModelState {
    [key: string]: string;
  }
  