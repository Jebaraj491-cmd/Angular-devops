export const camelCase = (word: string) => {
    return word[0].toLowerCase() + word.slice(1);
  };
  