export let CONFIG = {
    apiUrl: 'https://learnsmartcoding-restaurant.azurewebsites.net/api',        
    apiEndpoints: {
        category: 'category',
        cuisine: 'cuisine',
        foodmenu: 'foodmenu'
    }
};
